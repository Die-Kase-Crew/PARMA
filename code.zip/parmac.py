import os
import sys

def read_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def combine_par_headers(par_files):
    combined = ""
    for par_file in par_files:
        combined += read_file(par_file) + "\n"
    return combined

def parma_to_bkasm(source_code: str) -> list[str]:
    """
    Übersetzt PARMA-Quellcode in einfache BKASM-Befehle.
    """
    lines = source_code.splitlines()
    asm = []

    for line in lines:
        line = line.strip()
        if line.startswith("print("):
            content = line[len("print("):].rstrip(");").strip('"')
            asm.append(f'LOAD R1, "{content}"')
            asm.append("PRINT R1")
        elif line.startswith("main()"):
            asm.append("; ENTRYPOINT")
        elif line == "}":
            asm.append("RET")
        # TODO: weitere Syntax hier ergänzen

    return asm

def bkasm_to_bytecode(asm: list[str]) -> bytes:
    """
    Wandelt einfache Assembly-Zeilen in binären Bytecode um.
    """
    opcodes = {
        "LOAD": b'\x01',
        "PRINT": b'\x02',
        "RET": b'\xFF',
    }

    bytecode = b''
    for line in asm:
        parts = line.split()
        if not parts or parts[0].startswith(";"):
            continue

        cmd = parts[0]
        if cmd == "LOAD" and len(parts) >= 3:
            reg = parts[1].strip(",")
            value = line.split(",", 1)[1].strip().strip('"')
            bytecode += opcodes["LOAD"] + reg.encode("ascii") + value.encode("utf-8") + b'\x00'
        elif cmd == "PRINT":
            reg = parts[1]
            bytecode += opcodes["PRINT"] + reg.encode("ascii")
        elif cmd == "RET":
            bytecode += opcodes["RET"]
    return bytecode

def generate_bk(bytecode: bytes) -> bytes:
    """
    Baut .bk-Datei mit einfachem Header.
    """
    magic = b'BK01'
    size = len(bytecode).to_bytes(4, 'little')
    return magic + size + bytecode

def compile_parma(pa_file, par_files, out_file):
    print(f"[INFO] Compiling {pa_file} with headers {par_files}")
    headers = combine_par_headers(par_files)
    base_code = read_file(pa_file)
    full_code = headers + "\n" + base_code

    asm = parma_to_bkasm(full_code)
    machine_code = bkasm_to_bytecode(asm)
    bk_data = generate_bk(machine_code)

    with open(out_file, "wb") as f:
        f.write(bk_data)

    print(f"[OK] Output: {out_file} ({len(bk_data)} bytes)")

def main():
    if len(sys.argv) < 4:
        print("Nutzung: parmac.py quellcode.pa header1.par [header2.par ...] -o ausgabe.bk")
        sys.exit(1)

    try:
        output_index = sys.argv.index("-o")
        pa_file = sys.argv[1]
        par_files = sys.argv[2:output_index]
        out_file = sys.argv[output_index + 1]
    except (ValueError, IndexError):
        print("[FEHLER] Ungültige Argumente.")
        sys.exit(1)

    compile_parma(pa_file, par_files, out_file)

if __name__ == "__main__":
    main()
