import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import subprocess
import os

APP_TITLE = "PARMA Editor"
DEFAULT_FONT = ("Consolas", 12)
PARSER_PATH = "parmac.exe"  # Setzt voraus, dass parmac.exe im selben Ordner liegt

class ParmaEditor:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.file_path = None

        # Textfeld
        self.text = scrolledtext.ScrolledText(root, font=DEFAULT_FONT, undo=True, wrap="none")
        self.text.pack(fill="both", expand=True)

        # Menü
        menubar = tk.Menu(root)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Neu", command=self.new_file)
        filemenu.add_command(label="Öffnen...", command=self.open_file)
        filemenu.add_command(label="Speichern", command=self.save_file)
        filemenu.add_command(label="Speichern unter...", command=self.save_as_file)
        filemenu.add_separator()
        filemenu.add_command(label="Beenden", command=root.quit)
        menubar.add_cascade(label="Datei", menu=filemenu)

        buildmenu = tk.Menu(menubar, tearoff=0)
        buildmenu.add_command(label="Kompilieren", command=self.compile_file)
        menubar.add_cascade(label="PARMA", menu=buildmenu)

        root.config(menu=menubar)

    def new_file(self):
        self.text.delete("1.0", tk.END)
        self.file_path = None
        self.root.title(f"{APP_TITLE} – Neue Datei")

    def open_file(self):
        path = filedialog.askopenfilename(filetypes=[("PARMA-Dateien", "*.pa *.par")])
        if path:
            with open(path, "r", encoding="utf-8") as file:
                self.text.delete("1.0", tk.END)
                self.text.insert(tk.END, file.read())
            self.file_path = path
            self.root.title(f"{APP_TITLE} – {os.path.basename(path)}")

    def save_file(self):
        if self.file_path:
            with open(self.file_path, "w", encoding="utf-8") as file:
                file.write(self.text.get("1.0", tk.END))
        else:
            self.save_as_file()

    def save_as_file(self):
        path = filedialog.asksaveasfilename(defaultextension=".pa", filetypes=[("PARMA-Code", "*.pa"), ("PARMA-Header", "*.par")])
        if path:
            self.file_path = path
            self.save_file()
            self.root.title(f"{APP_TITLE} – {os.path.basename(path)}")

    def compile_file(self):
        if not self.file_path:
            messagebox.showerror("Fehler", "Speichere die Datei zuerst, bevor du sie kompilierst.")
            return

        self.save_file()

        try:
            result = subprocess.run(
                [PARSER_PATH, self.file_path],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                messagebox.showinfo("Kompilieren erfolgreich", f"Erstellt: {os.path.splitext(self.file_path)[0]}.bk")
            else:
                messagebox.showerror("Fehler beim Kompilieren", result.stderr)
        except FileNotFoundError:
            messagebox.showerror("Compiler nicht gefunden", f"'{PARSER_PATH}' wurde nicht gefunden.\nStelle sicher, dass parmac.exe im selben Ordner ist.")

# Start
if __name__ == "__main__":
    root = tk.Tk()
    editor = ParmaEditor(root)
    root.mainloop()
